import java.util.Scanner;
public class Uri1016{
	public static void main(String[] args){
		Scanner teclado = new Scanner(System.in);
		int distancia = teclado.nextInt();
		System.out.println((distancia * 2) + " minutos");
		teclado.close();
	}
}
